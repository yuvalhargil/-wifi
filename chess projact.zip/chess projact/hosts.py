import socket # תקשורת דרך האינטארנט 
import chess # חוקי השחמט
import pygame # לוח גרפי
import sys # מציאת הקבצים
import os # יבוא תמונות הכלים

WIDTH, HEIGHT = 600, 680  # גודל מסך
SQ_SIZE = WIDTH // 8 # גודל משבצת
COLORS = [pygame.Color("#eeeed2"), pygame.Color("#769656")] # צבעי המשבצות
PORT = 50000 # הפורט של תקשורת באינטארנט 

def load_images():   # טוען את התמונות של הכלים
    pieces = ['pawn', 'knight', 'bishop', 'rook', 'queen', 'king'] #שמות הכלים
    images = {}
    os.chdir(os.path.dirname(os.path.abspath(__file__))) # מחפש את התיקייה 
    for p in pieces: # עובר על כל הכלים
        try: # מחפש את הכלים כל כלי רשום או בשמו ללבן או בשמו פלוס d לשחור
            images[f"W_{p}"] = pygame.transform.scale(pygame.image.load(f"pieces/{p}.png"), (SQ_SIZE, SQ_SIZE)) # מנסה לטעון את הכלי הלבן
            images[f"B_{p}"] = pygame.transform.scale(pygame.image.load(f"pieces/d{p}.png"), (SQ_SIZE, SQ_SIZE)) # מנסה לטעון את הכלי בשחור בגל זה רשום d
        except: # לא אמור לקראת רק אם  לא מצא את התמונות
            print("שגיאה בטעינת תמונות") 
            sys.exit()
    return images # מחזיר את התמונות כדי שהיה אפשר להשתמש בהם

def draw_window(screen, board, images, input_text, font):
    # ציור הלוח
    for r in range(8): 
        for c in range(8):
            color = COLORS[((r + c) % 2)]
            pygame.draw.rect(screen, color, pygame.Rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE, SQ_SIZE))
            piece = board.piece_at(chess.square(c, 7-r))
            if piece:
                color_code = 'W' if piece.color == chess.WHITE else 'B' # נותן צבע לכלי מבחינת הפייטון לא רק התמונה
                piece_type = chess.piece_name(piece.piece_type)
                screen.blit(images[f"{color_code}_{piece_type}"], (c*SQ_SIZE, r*SQ_SIZE))# מגדיר מה יש במסך

    
    pygame.draw.rect(screen, (50, 50, 50), pygame.Rect(0, 600, 600, 80))  # החלק בו מקלידים את המהלכים
    
    # הצגת הטקסט המוקלד
    text_surface = font.render(f"Enter Move: {input_text}", True, (255, 255, 255))
    screen.blit(text_surface, (20, 625))
    
    
    turn_msg = "YOUR TURN (WHITE)" if board.turn == chess.WHITE else "WAITING FOR BLACK..." # אומר תור מי כדי שידעו לעשות מהלך
    turn_surface = font.render(turn_msg, True, (0, 255, 0) if board.turn == chess.WHITE else (200, 200, 200))
    screen.blit(turn_surface, (350, 625)) # רושם לך תור מי

def main(): # המשחק עצמו הפעולות יצירת שרת  ומשחק
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", PORT))
    server.listen(1) # מצב האזנה מחכה לנסיון כניסה דרך פורט 50000 
    
    print(f"IP: {socket.gethostbyname(socket.gethostname())}") # מדפיס את הכתובת IP של המחשב בתוך הרשת כדי שהגסט יוכל לשלוח בקשת התחברות לשרת  
    
    pygame.init() # מפעיל את המסך
    screen = pygame.display.set_mode((WIDTH, HEIGHT)) # גודל המסך 
    pygame.display.set_caption("Chess Host - White") # רושם שההוסט הוא הלבן 
    font = pygame.font.SysFont("Arial", 24) # הגדרת מאפיני התצוגה של הטקסט הפונט והגודל 
    
    conn, addr = server.accept() # מאשר כל בקשת התחברות לשרת צפויה בקשה רק מקובץ גאסט
    conn.setblocking(False) #  מוריד חסימה מהשרת כל אחד יכול להיכנס אם הוא בתוך הwifi כמו האוסט
    
    images = load_images() # טעינת התמונות 
    board = chess.Board() # יצירת הלוח
    input_text = ""
    running = True # מגדיר שפועל ( running = נכון)
    
    while running: # כמו לרשום while True
        try:
            msg = conn.recv(1024).decode("utf-8").strip() # מחכה לקבל סוג של הודעת מהלך שחמט בעורך של עד 1024 בייטס 
            if msg: board.push(chess.Move.from_uci(msg)) # מוודא שהמהלך חוקי לפי חוקי השחמט שמוגדרים בחבילה chess
        except: pass

        for event in pygame.event.get(): # מחכה שיקבל אירוע 
            if event.type == pygame.QUIT: # אם האירוע זה סגירת התוכנית(התנתקות) 
                running = False # ראנינג שווה לא נכון ומכבה את הלולאה בשורה 70
            
            if event.type == pygame.KEYDOWN and board.turn == chess.WHITE: # אם נחץ מקש בזמן שתור לבן
                if event.key == pygame.K_RETURN: 
                    try: # מנסה לעשות את המהלך שנרשם 
                        move = chess.Move.from_uci(input_text.lower()) # מקליד מהלך לפי קידוד uci
                        if move in board.legal_moves: # בודק האם המהלך חוקי על פי הסיטואציה הנתונה בלוח
                            board.push(move) # אם חוקי מבצע את המהלך ומציג את הביוע על הלוח
                            conn.sendall((input_text.lower() + "\n").encode("utf-8")) # מעדכן את המחשב השני על ביצוע המהלך
                    except: pass
                    input_text = ""
                elif event.key == pygame.K_BACKSPACE: # במקרה שרשמו עם רווח בין המהלכים מוריד אותו
                    input_text = input_text[:-1]
                else:
                    if len(input_text) < 4: # רשופ פחות מ4 תווים המהלך לא יכול להיות 
                        input_text += event.unicode # מחכה שירשם מהלך אחר 

        draw_window(screen, board, images, input_text, font) # מצייר את המסך
        pygame.display.flip() # עובר ללחכות למהלך של השחקן השני 

    pygame.quit() # סגירת התוכנית 
    sys.exit() 

if __name__ == "__main__": # הפעלת התוכנית
    main()