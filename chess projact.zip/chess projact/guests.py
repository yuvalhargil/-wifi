import socket # עבור תקשורת דרך האינטארנט 
import chess # חוקי השחמט
import pygame # עבור גרפיקה 
import sys # עבור מציאת הנתיב של הקבצים כי לא בכל המחשבים ישמרו את התיקייה באותו המקום
import os # עבור העלאת הקבצים 

WIDTH, HEIGHT = 600, 680 # גודל המסך
SQ_SIZE = WIDTH // 8 # גודל המשבצת
COLORS = [pygame.Color("#eeeed2"), pygame.Color("#769656")]  # צבעי המשבצות
PORT = 50000 # הפורט משמשמש עבור תקשורת באינטארנט 

def load_images(): # הפונקצייה האחראית למציאת וטעינת התמונות
    pieces = ['pawn', 'knight', 'bishop', 'rook', 'queen', 'king']   # שמות הכלים הבסיסים
    images = {} 
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    for p in pieces:
        try:
            images[f"W_{p}"] = pygame.transform.scale(pygame.image.load(f"pieces/{p}.png"), (SQ_SIZE, SQ_SIZE)) # מציאת הנתיב של התמונות של הכלים הלבנים
            images[f"B_{p}"] = pygame.transform.scale(pygame.image.load(f"pieces/d{p}.png"), (SQ_SIZE, SQ_SIZE)) # מציאת הנתיב של הכלים השחורים d עומד עבור dark 
        except: sys.exit() # כדי שלא יקרוס במקרה שלא מוצא את התמונה
    return images # מייבא את התמונות 

def draw_window(screen, board, images, input_text, font): # אחראי על נראות המסך מבחינת הופעתת הלוח פונט וכו
    for r in range(8): # חלק ראשון מיצירתם וצביעתם של המשבצות 
        for c in range(8): # חלק שני מיצירתם וצביעתם של המשבצות
            color = COLORS[((r + c) % 2)] # חלק בחירת הצבע עבור כל משבצת לפי מיקומה
            pygame.draw.rect(screen, color, pygame.Rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE, SQ_SIZE))
            piece = board.piece_at(chess.square(c, 7-r)) # קובע את מיקום של החיילים pawns
            if piece: # מגדיר את הכלים
                color_code = 'W' if piece.color == chess.WHITE else 'B' # w עם הכלי לבן b עם הכלי שחור
                piece_type = chess.piece_name(piece.piece_type) # מגדיר ששם הכלי זה השם שלו פלוס לבן או שחור
                screen.blit(images[f"{color_code}_{piece_type}"], (c*SQ_SIZE, r*SQ_SIZE)) # כל כלי מוצג במיקום שלו

    pygame.draw.rect(screen, (50, 50, 50), pygame.Rect(0, 600, 600, 80)) # מייצר את מסך כתיבת המהלכים 
    text_surface = font.render(f"Enter Move: {input_text}", True, (255, 255, 255)) # מגדיר מה היה רשום לשחקן ע מסך כתיבת המהלכים כמו בinput(' g') והצבע
    screen.blit(text_surface, (20, 625)) # מיקום המסך  הכנת המהלכים 
    
    turn_msg = "YOUR TURN (BLACK)" if board.turn == chess.BLACK else "WAITING FOR WHITE..." # מגדיר מה היה רשום לך תורך שחור או מחכה  ללבן
    turn_surface = font.render(turn_msg, True, (0, 255, 0) if board.turn == chess.BLACK else (200, 200, 200)) # מיקום ההודעה וצבעה
    screen.blit(turn_surface, (350, 625)) #  מיקום ההודעה

def main():
    host_ip = input("הכנס IP של המארח: ").strip()  # מבק את הip של המארח  עבור שליחת בקשת התחברות לשרת
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # מוצא את השרת
    sock.connect((host_ip, PORT)) # מתחבר לשרת 
    sock.setblocking(False) # עושה שמתחבר לשרת לל חסימות

    pygame.init() # ההפעלה של המסך 
    screen = pygame.display.set_mode((WIDTH, HEIGHT)) # מגדיר את המסך 
    pygame.display.set_caption("Chess Guest - Black") # כותרת המסך
    font = pygame.font.SysFont("Arial", 24) # הפונט שבו ישתמשו במסך
    
    images = load_images() # טעינת התמונות 
    board = chess.Board() # יצירת הלוח
    input_text = "" # אינפוט רק 
    running = True #  מפעיל את הלולאה בשורה 58 
    
    while running:  # קצת כמו לרשום while True רק שיותר קל לשנות אחרכך ולכבות
        try: # שליחת המהלכית והתחברות וקבלת המהלכים 
            msg = sock.recv(1024).decode("utf-8").strip() # הגבלה של כמות הבתים שאפשר לשלוח או לקבל
            if msg: board.push(chess.Move.from_uci(msg)) # אם המהלך תקין מבחינת כתיבה וחוקי בצע אותו
        except: pass

        for event in pygame.event.get():  # במקרה שסוגרים את התוכנית כבה את הקשר עם המחשב השני ואת המשחק
            if event.type == pygame.QUIT:
                running = False
            
            if event.type == pygame.KEYDOWN and board.turn == chess.BLACK: # אם לוחצים על מקש עשה אותו
                if event.key == pygame.K_RETURN:
                    try: # אם שילוב המקשים יוצר מהלך חוקי לפי תזוזה ודברים בסגנון שח בצע אותו
                        move = chess.Move.from_uci(input_text.lower())
                        if move in board.legal_moves:
                            board.push(move)
                            sock.sendall((input_text.lower() + "\n").encode("utf-8"))
                    except: pass
                    input_text = ""
                elif event.key == pygame.K_BACKSPACE: # אם לוחצים על מקש רווח הורד אותו
                    input_text = input_text[:-1]
                else:
                    if len(input_text) < 4: # על תשלח מהלכים עם פחות מ4 תוים זה לא אפשרי
                        input_text += event.unicode

        draw_window(screen, board, images, input_text, font) # מצייר את המסך על פי ההגדרות שהוגדרו ממקודם עבור כל אלמנט שלו 
        pygame.display.flip() 

    pygame.quit() #סגור את החלון
    sys.exit()

if __name__ == "__main__": # מפעיל 
    main() # מפעיל את הפונקצייה מיין 